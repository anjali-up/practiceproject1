package TypeCastingprogram;

public class animalinheritance extends Doginheritanceprogram {
	public void animalclass() {
		System.out.println("This is the multilevel inheritance");
	}

}
