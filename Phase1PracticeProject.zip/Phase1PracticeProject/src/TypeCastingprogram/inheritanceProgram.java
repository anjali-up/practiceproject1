package TypeCastingprogram;

public class inheritanceProgram extends Doginheritanceprogram{
	public void cloth() {
		System.out.println("this is the child class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Single Inheritance Program
		inheritanceProgram obj = new inheritanceProgram();
		obj.dogeat();
		obj.cloth();
		
	}

}
