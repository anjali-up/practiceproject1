package TypeCastingprogram;

public class tryblockwithparametersprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 0;
		try {
			dividenet(a,b);
		}catch(ArithmeticException e) {
			System.out.println(e.getMessage());
		}

	}

	private static void dividenet(int dividend, int divisor) {
		// TODO Auto-generated method stub
		if(divisor == 0) {
			throw new ArithmeticException("Cannot divide by 0");
		}
		else {
			int result = dividend / divisor;
			System.out.println(result);
		}
		
	}

}
