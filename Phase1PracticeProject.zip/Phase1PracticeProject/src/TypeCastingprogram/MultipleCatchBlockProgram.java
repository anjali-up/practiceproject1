package TypeCastingprogram;

public class MultipleCatchBlockProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,2,3,4};
		try {
			int result = arr[5];
			System.out.println("Result is : " + result);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Out of index");
		}catch(Exception e) {
			System.out.println("Invalid input");
		}

	}

}
