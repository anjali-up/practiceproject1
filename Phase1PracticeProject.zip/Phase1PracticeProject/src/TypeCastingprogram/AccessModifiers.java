package TypeCastingprogram;

public class AccessModifiers {
	public int publicVar = 10;
	private int privateVar = 20;
	protected int protectedVar = 30;
	public void publicMethod() {
		System.out.println("this is the public method");
	}
	private void privateMethod() {
		System.out.println("this is the private method");
	}
	protected void protectedMethod() {
		System.out.println("this is the protected method");
	}
	void defaultMethod() {
		System.out.println("this is the defaule method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifiers obj = new AccessModifiers();
		System.out.println("Public Variable variable : " + obj.publicVar);
		System.out.println("private Variable variable : " + obj.privateVar);
		System.out.println("protected Variable variable : " + obj.protectedVar);
		obj.publicMethod();
		obj.privateMethod();
		obj.protectedMethod();

	}

}
