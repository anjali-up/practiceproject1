package TypeCastingprogram;

public class WhileLoopProgramDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count  = 1;
		while(count <=10) {
			System.out.println("This is the while loop program :" + count);
			count++;
		}

	}

}
