package TypeCastingprogram;

public class TrycatchProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] i = {1,2}; 
		try {
			System.out.println(i[3]);
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("The index number is out of boundery");
			
		}

	}

}
