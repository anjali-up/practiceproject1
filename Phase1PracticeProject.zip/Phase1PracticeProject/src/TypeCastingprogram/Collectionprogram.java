package TypeCastingprogram;

import java.util.ArrayList;
import java.util.Collection;

public class Collectionprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Collection<String> myCollectionpro = new ArrayList<>();
		myCollectionpro.add("red");
		myCollectionpro.add("pink");
		myCollectionpro.add("black");
		myCollectionpro.add("blue");
		myCollectionpro.add("purple");
		
		System.out.println("Color's in the collection are : " + myCollectionpro);
		System.out.println("Does black exist in the collection? " + myCollectionpro.contains("black"));
		myCollectionpro.remove("red");
		System.out.println(myCollectionpro);
		System.out.println("Is the collection is empty :" + myCollectionpro.isEmpty());
		System.out.println("What is the size of the collection : " + myCollectionpro.size());
		

	}

}
