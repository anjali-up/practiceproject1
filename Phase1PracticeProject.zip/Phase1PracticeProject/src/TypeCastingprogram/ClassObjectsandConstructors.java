package TypeCastingprogram;

	public class ClassObjectsandConstructors{
		ClassObjectsandConstructors(){
			System.out.println("This is the program of Class, Object and Connstructor");
		}

	public static void main(String[] args) {
		ClassObjectsandConstructors obj = new ClassObjectsandConstructors();
		//System.out.println("This is the class, objects and construtors " + obj);

	}

}
