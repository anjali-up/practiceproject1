package TypeCastingprogram;

public class DoWhileLoopProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int var = 1;
		do{
			System.out.println("Thi is the Do While Loop : " + var);
			var++;
		}while(var <= 5);

	}

}
