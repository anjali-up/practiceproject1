package TypeCastingprogram;

public class Doginheritanceprogram {
	public void dogeat() {
		System.out.println("This is the parent class");
	}

}
