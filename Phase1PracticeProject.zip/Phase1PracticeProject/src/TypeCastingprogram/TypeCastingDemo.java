package TypeCastingprogram;

public class TypeCastingDemo {

	public static void main(String[] args) {
		//Implicite type Casting
		int i = 10;
		long n = i;
		System.out.println("This is the Implicite Type Casting : " + n);
		
		//Explicite Type Casting
		long l= 2346;
		int m = (int) (l);
		System.out.println("This is the Explicite Type Casting : " + m);
		

	}

}
