package TypeCastingprogram;

import java.io.IOException;

public class throwsKeywordProgram {
	static void validate(int age) throws IOException,ArithmeticException{
		if(age<18) {
			throw new ArithmeticException("Not eligible for Voting.It should be above 18 years");
		}
		else {
			System.out.println("Eligible to Vote");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			validate(10);
		}catch(Exception e){
			System.out.println(e.getMessage());
			
		}

	}

}
